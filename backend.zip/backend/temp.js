console.log("sending data");
setTimeout(()=>console.log("information is on the way"),4000);
console.log("at the end of request");